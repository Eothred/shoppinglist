# Defaults for shoppinglist initscript
# sourced by /etc/init.d/shoppinglist
# installed at /etc/default/shoppinglist by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
