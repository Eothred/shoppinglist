#
# Regular cron jobs for the shoppinglist package
#
0 4	* * *	root	shoppinglist_maintenance
