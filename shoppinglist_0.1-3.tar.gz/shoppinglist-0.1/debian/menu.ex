?package(shoppinglist):needs="X11|text|vc|wm" section="Apps/see-menu-manual"\
  title="shoppinglist" command="/usr/bin/shoppinglist"
