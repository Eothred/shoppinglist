/********************************************************************************
** Form generated from reading UI file 'shoppinglistform.ui'
**
** Created: Sun Aug 1 14:00:58 2010
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SHOPPINGLISTFORM_H
#define UI_SHOPPINGLISTFORM_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QGridLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QPushButton>
#include <QtGui/QScrollBar>
#include <QtGui/QSpacerItem>
#include <QtGui/QVBoxLayout>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ShoppingListForm
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *mainLayout;
    QPushButton *newItemButton;
    QSpacerItem *verticalSpacer;
    QScrollBar *verticalScrollBar;

    void setupUi(QWidget *ShoppingListForm)
    {
        if (ShoppingListForm->objectName().isEmpty())
            ShoppingListForm->setObjectName(QString::fromUtf8("ShoppingListForm"));
        ShoppingListForm->resize(400, 300);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(ShoppingListForm->sizePolicy().hasHeightForWidth());
        ShoppingListForm->setSizePolicy(sizePolicy);
        gridLayout = new QGridLayout(ShoppingListForm);
#ifndef Q_OS_MAC
        gridLayout->setSpacing(6);
#endif
#ifndef Q_OS_MAC
        gridLayout->setContentsMargins(9, 9, 9, 9);
#endif
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        mainLayout = new QVBoxLayout();
        mainLayout->setObjectName(QString::fromUtf8("mainLayout"));

        gridLayout->addLayout(mainLayout, 0, 1, 1, 1);

        newItemButton = new QPushButton(ShoppingListForm);
        newItemButton->setObjectName(QString::fromUtf8("newItemButton"));

        gridLayout->addWidget(newItemButton, 1, 1, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 2, 1, 1, 1);

        verticalScrollBar = new QScrollBar(ShoppingListForm);
        verticalScrollBar->setObjectName(QString::fromUtf8("verticalScrollBar"));
        verticalScrollBar->setOrientation(Qt::Vertical);

        gridLayout->addWidget(verticalScrollBar, 0, 2, 1, 1);


        retranslateUi(ShoppingListForm);

        QMetaObject::connectSlotsByName(ShoppingListForm);
    } // setupUi

    void retranslateUi(QWidget *ShoppingListForm)
    {
        ShoppingListForm->setWindowTitle(QApplication::translate("ShoppingListForm", "Shopping List", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        newItemButton->setToolTip(QApplication::translate("ShoppingListForm", "Add a new item", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        newItemButton->setText(QApplication::translate("ShoppingListForm", "New item", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class ShoppingListForm: public Ui_ShoppingListForm {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SHOPPINGLISTFORM_H
