/********************************************************************************
** Form generated from reading UI file 'itemFrame.ui'
**
** Created: Sun Aug 1 14:00:59 2010
**      by: Qt User Interface Compiler version 4.6.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ITEMFRAME_H
#define UI_ITEMFRAME_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QDialogButtonBox>
#include <QtGui/QGridLayout>
#include <QtGui/QHBoxLayout>
#include <QtGui/QHeaderView>
#include <QtGui/QLineEdit>
#include <QtGui/QSpacerItem>
#include <QtGui/QWidget>

QT_BEGIN_NAMESPACE

class Ui_itemFrame
{
public:
    QGridLayout *gridLayout;
    QHBoxLayout *itemLayout;
    QCheckBox *haveFoundCheckBox;
    QLineEdit *numberOfItems;
    QLineEdit *itemName;
    QSpacerItem *horizontalSpacer;
    QDialogButtonBox *deleteButton;

    void setupUi(QWidget *itemFrame)
    {
        if (itemFrame->objectName().isEmpty())
            itemFrame->setObjectName(QString::fromUtf8("itemFrame"));
        itemFrame->resize(400, 46);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(itemFrame->sizePolicy().hasHeightForWidth());
        itemFrame->setSizePolicy(sizePolicy);
        gridLayout = new QGridLayout(itemFrame);
#ifndef Q_OS_MAC
        gridLayout->setSpacing(6);
#endif
#ifndef Q_OS_MAC
        gridLayout->setContentsMargins(9, 9, 9, 9);
#endif
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        itemLayout = new QHBoxLayout();
        itemLayout->setObjectName(QString::fromUtf8("itemLayout"));
        haveFoundCheckBox = new QCheckBox(itemFrame);
        haveFoundCheckBox->setObjectName(QString::fromUtf8("haveFoundCheckBox"));

        itemLayout->addWidget(haveFoundCheckBox);

        numberOfItems = new QLineEdit(itemFrame);
        numberOfItems->setObjectName(QString::fromUtf8("numberOfItems"));
        numberOfItems->setMaximumSize(QSize(40, 16777215));

        itemLayout->addWidget(numberOfItems);

        itemName = new QLineEdit(itemFrame);
        itemName->setObjectName(QString::fromUtf8("itemName"));

        itemLayout->addWidget(itemName);

        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        itemLayout->addItem(horizontalSpacer);

        deleteButton = new QDialogButtonBox(itemFrame);
        deleteButton->setObjectName(QString::fromUtf8("deleteButton"));
        deleteButton->setStandardButtons(QDialogButtonBox::Discard);
        deleteButton->setCenterButtons(false);

        itemLayout->addWidget(deleteButton);


        gridLayout->addLayout(itemLayout, 0, 2, 1, 1);

        QWidget::setTabOrder(itemName, numberOfItems);
        QWidget::setTabOrder(numberOfItems, haveFoundCheckBox);
        QWidget::setTabOrder(haveFoundCheckBox, deleteButton);

        retranslateUi(itemFrame);
        QObject::connect(deleteButton, SIGNAL(clicked(QAbstractButton*)), itemName, SLOT(clear()));
        QObject::connect(deleteButton, SIGNAL(clicked(QAbstractButton*)), numberOfItems, SLOT(clear()));

        QMetaObject::connectSlotsByName(itemFrame);
    } // setupUi

    void retranslateUi(QWidget *itemFrame)
    {
        itemFrame->setWindowTitle(QApplication::translate("itemFrame", "Shopping List", 0, QApplication::UnicodeUTF8));
        haveFoundCheckBox->setText(QString());
#ifndef QT_NO_TOOLTIP
        numberOfItems->setToolTip(QApplication::translate("itemFrame", "Write number of units", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        numberOfItems->setText(QApplication::translate("itemFrame", "1", 0, QApplication::UnicodeUTF8));
#ifndef QT_NO_TOOLTIP
        itemName->setToolTip(QApplication::translate("itemFrame", "Write item", 0, QApplication::UnicodeUTF8));
#endif // QT_NO_TOOLTIP
        itemName->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class itemFrame: public Ui_itemFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ITEMFRAME_H
